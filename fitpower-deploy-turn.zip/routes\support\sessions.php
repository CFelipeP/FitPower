<?php

function listSessions(): void {
    $auth = requireAuth();
    $db = getDB();

    $programId = $_GET['program_id'] ?? '';
    $trainerId = $_GET['trainer_id'] ?? '';
    $date = $_GET['date'] ?? '';

    $where = [];
    $params = [];

    if ($programId) {
        $where[] = "s.program_id = ?";
        $params[] = $programId;
    }
    if ($trainerId) {
        $where[] = "s.trainer_id = ?";
        $params[] = $trainerId;
    }
    if ($date) {
        $where[] = "s.date = ?";
        $params[] = $date;
    }

    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $stmt = $db->prepare("
        SELECT s.*, 
            CONCAT(t.first_name, ' ', t.last_name) as trainer_name,
            p.name as program_name
        FROM sessions s
        LEFT JOIN trainers t ON t.id = s.trainer_id
        LEFT JOIN programs p ON p.id = s.program_id
        $whereClause
        ORDER BY s.date, s.start_time
    ");
    $stmt->execute($params);
    $sessions = $stmt->fetchAll();

    $result = array_map(function($s) {
        return [
            'id' => (int)$s['id'],
            'programId' => $s['program_id'] ? (int)$s['program_id'] : null,
            'trainerId' => $s['trainer_id'] ? (int)$s['trainer_id'] : null,
            'trainerName' => $s['trainer_name'],
            'programName' => $s['program_name'],
            'title' => $s['title'],
            'description' => $s['description'],
            'date' => $s['date'],
            'startTime' => $s['start_time'],
            'endTime' => $s['end_time'],
            'type' => $s['type'],
            'status' => $s['status'],
            'rpe' => $s['rpe'] ? (int)$s['rpe'] : null,
            'rpeNotes' => $s['rpe_notes'],
        ];
    }, $sessions);

    success($result);
}

function createSession(): void {
    $auth = requireAuth();
    if (!in_array($auth['role'] ?? '', ['admin', 'coach'], true)) {
        error('Solo entrenadores y administradores pueden crear sesiones', 403);
    }
    $input = getJsonInput();

    $rules = [
        'title' => 'required|string|min:1|max:255',
        'date' => 'required|string',
    ];

    $errors = validate($input, $rules);
    if ($errors) {
        error('Error de validación', 422, $errors);
    }

    $db = getDB();

    $trainerId = $input['trainerId'] ?? null;
    if ($auth['role'] === 'coach') {
        $tStmt = $db->prepare("SELECT id FROM trainers WHERE user_id = ?");
        $tStmt->execute([$auth['sub']]);
        $coachTrainerId = $tStmt->fetchColumn();
        if (!$coachTrainerId) error('Perfil de entrenador no encontrado', 404);
        if ($trainerId !== null && (int)$trainerId !== (int)$coachTrainerId) {
            error('No tienes permisos para crear sesiones para otro entrenador', 403);
        }
        $trainerId = (int)$coachTrainerId;
    }

    $stmt = $db->prepare("
        INSERT INTO sessions (program_id, trainer_id, title, description, date, start_time, end_time, type, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $input['programId'] ?? null,
        $trainerId,
        $input['title'],
        $input['description'] ?? null,
        $input['date'],
        $input['startTime'] ?? null,
        $input['endTime'] ?? null,
        $input['type'] ?? 'group',
        $input['status'] ?? 'scheduled',
    ]);

    $sessionId = (int)$db->lastInsertId();

    if (!empty($input['exercises'])) {
        $exStmt = $db->prepare("
            INSERT INTO exercises (session_id, name, sets, reps, weight, notes, sort_order)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($input['exercises'] as $i => $ex) {
            $exStmt->execute([
                $sessionId,
                $ex['name'] ?? '',
                $ex['sets'] ?? null,
                $ex['reps'] ?? null,
                $ex['weight'] ?? null,
                $ex['notes'] ?? null,
                $i + 1,
            ]);
        }
    }

    success(['id' => $sessionId], 'Sesión creada', 201);
}

function updateSession(string $id): void {
    $auth = requireAuth();
    $input = getJsonInput();

    $db = getDB();

    $stmt = $db->prepare("SELECT s.id, s.trainer_id, t.user_id FROM sessions s LEFT JOIN trainers t ON t.id = s.trainer_id WHERE s.id = ?");
    $stmt->execute([$id]);
    $session = $stmt->fetch();
    if (!$session) {
        error('Sesión no encontrada', 404);
    }

    $isOwner = $session['trainer_id'] && $session['user_id'] && (int)$session['user_id'] === $auth['sub'];
    if (!in_array($auth['role'] ?? '', ['admin'], true) && !$isOwner) {
        error('No tienes permisos para modificar esta sesión', 403);
    }

    $fieldMap = [
        'title' => 'title',
        'description' => 'description',
        'date' => 'date',
        'startTime' => 'start_time',
        'endTime' => 'end_time',
        'type' => 'type',
        'status' => 'status',
        'programId' => 'program_id',
        'trainerId' => 'trainer_id',
        'rpe' => 'rpe',
        'rpeNotes' => 'rpe_notes',
    ];

    $updates = [];
    $params = [];

    foreach ($fieldMap as $inputKey => $dbColumn) {
        if (isset($input[$inputKey])) {
            $updates[] = "$dbColumn = ?";
            $params[] = $input[$inputKey];
        }
    }

    if (!empty($updates)) {
        $params[] = $id;
        $db->prepare("UPDATE sessions SET " . implode(', ', $updates) . " WHERE id = ?")
            ->execute($params);
    }

    if (!empty($input['status']) && $input['status'] === 'completed') {
        $userId = $auth['sub'];
        $db->prepare("INSERT INTO leaderboard_entries (user_id, points, workouts_completed, updated_at) 
            VALUES (?, 10, 1, NOW()) 
            ON DUPLICATE KEY UPDATE points = points + 10, workouts_completed = workouts_completed + 1, updated_at = NOW()")
            ->execute([$userId]);
        require_once __DIR__ . '/../gamification/achievements.php';
        checkAndUnlockAchievements();
    }

    success(null, 'Sesión actualizada');
}

function deleteSession(string $id): void {
    $auth = requireAuth();
    $db = getDB();

    $stmt = $db->prepare("SELECT s.id, s.trainer_id, t.user_id FROM sessions s LEFT JOIN trainers t ON t.id = s.trainer_id WHERE s.id = ?");
    $stmt->execute([$id]);
    $session = $stmt->fetch();
    if (!$session) {
        error('Sesión no encontrada', 404);
    }

    $isOwner = $session['trainer_id'] && $session['user_id'] && (int)$session['user_id'] === $auth['sub'];
    if (!in_array($auth['role'] ?? '', ['admin'], true) && !$isOwner) {
        error('No tienes permisos para eliminar esta sesión', 403);
    }

    $db->prepare("DELETE FROM sessions WHERE id = ?")->execute([$id]);
    success(null, 'Sesión eliminada');
}
